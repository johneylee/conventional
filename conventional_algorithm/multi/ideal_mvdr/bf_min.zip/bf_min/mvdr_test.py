import numpy as np
import soundfile as sf
import os
import util
import BF.minimum_variance_distortioless_response as mvdr
import pdb
import scipy.io.wavfile as wavfile
import sys
sys.path.insert(0, "/home/minhtri/AE/")
import ssplib


###################################################### ALL CONFIGURATIONS ################################################
SAMPLING_FREQUENCY = 16000
FFT_LENGTH = 512
FFT_SHIFT = 256
ENHANCED_WAV_NAME = 'enhanced_speech_mvdr.wav'
MIC_ANGLE_VECTOR = np.array([90, 270])
LOOK_DIRECTION = 0
MIC_DIAMETER = 0.08

noisy_list = ssplib.read_txt_file('/home/minhtri/AE/Statistical BF/bf_min/data/LOG/test_noisy_list.txt')

enhanced_dir = "/home/minhtri/AE/Statistical BF/bf_min/data/enhanced/steer_follow_source"
ssplib.make_sure_path_exists(enhanced_dir)

log_dir = "/home/minhtri/AE/Statistical BF/bf_min/data/LOG"
##########################################################################################################################

enhanced_wav_list = []
for i in range(len(noisy_list)):
    file = noisy_list[i] +'.wav'
    noisy, fs = sf.read(file, dtype='float32')

    source_angle = int(file.split('1a')[1].split('_')[0])
    if source_angle < 0:
    	source_angle += 360
    # print("file: ", file, "   \n angle: ", source_angle)
    
    LOOK_DIRECTION = source_angle

    # start MVDR
    complex_spectrum, _ = util.get_3dim_spectrum_from_data(noisy, FFT_LENGTH, FFT_SHIFT, FFT_LENGTH)
    mvdr_beamformer = mvdr.minimum_variance_distortioless_response(MIC_ANGLE_VECTOR, MIC_DIAMETER, sampling_frequency=SAMPLING_FREQUENCY, fft_length=FFT_LENGTH, fft_shift=FFT_SHIFT)
    steering_vector = mvdr_beamformer.get_sterring_vector(LOOK_DIRECTION)
    spatial_correlation_matrix = mvdr_beamformer.get_spatial_correlation_matrix(noisy)
    beamformer = mvdr_beamformer.get_mvdr_beamformer(steering_vector, spatial_correlation_matrix)
    enhanced_speech = mvdr_beamformer.apply_beamformer(beamformer, complex_spectrum)
    enhanced_speech = np.max(noisy)*enhanced_speech / np.max(np.abs(enhanced_speech))
    # finish MVDR
    
    wavname = os.sep.join(file.split(os.sep)[-3:])
    savename = os.path.join(os.path.join(enhanced_dir, wavname))
    ssplib.make_sure_path_exists(os.path.dirname(savename))
    sf.write(savename, enhanced_speech, SAMPLING_FREQUENCY)
    enhanced_wav_list.append(savename)
    print('[{}/{}]: {}'.format(i, len(noisy_list), savename))
    
ssplib.list_to_txt_file(os.path.join(log_dir ,'mvdr_enhanced_wav_list.txt'), enhanced_wav_list)  