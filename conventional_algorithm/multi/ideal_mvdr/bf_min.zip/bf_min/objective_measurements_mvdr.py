import numpy as np
import scipy.io.wavfile as wav
import os
from tqdm import tqdm
import logging
import time
import sys
sys.path.insert(0, "/home/minhtri/AE/")
import ssplib
import pdb
import matplotlib.pyplot as plt
###################################### ALL COFIGURATION #########################
result_dir = os.path.join('/home/minhtri/AE/Statistical BF/bf_min/data/LOG')

project_dir = os.getcwd()
DB_dir = '/home/minhtri/AE/DB/TIMIT/TEST_CORE'

enhanced_wav_list = ssplib.read_txt_file('/home/minhtri/AE/Statistical BF/bf_min/data/LOG/mvdr_enhanced_wav_list.txt')

# ntype_lib = ['babble', 'factory1', 'white', 'aurora4_restaurant_1', 'destroyerengine', 'aurora4_exhibition_1']
ntype_lib = ["aurora4_airport_1", "aurora4_lobby_1", "aurora4_station_1", "babble", "destroyerops", "DLIVING", "factory1", "leopard", "pink", "SPSQUARE", "STRAFFIC", "volvo", "aurora4_benz_1", "aurora4_exhibition_1", "dcube_record", "destroyerengine"]
snrtype_lib = ['-10dB', '-5dB', '0dB', '5dB', '10dB']

################################################################################



def lets_log(log_dir):
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    stream_hander = logging.StreamHandler()
    logger.addHandler(stream_hander)
    file_handler = logging.FileHandler(os.path.join(log_dir))
    logger.addHandler(file_handler)
    return logger
logger = lets_log(os.path.join(result_dir, 'score_steer_follow_source.txt'))


score_sdr = [[[] for n in range(len(snrtype_lib))] for m in range(len(ntype_lib))]
score_stoi = [[[] for n in range(len(snrtype_lib))] for m in range(len(ntype_lib))]

start_time = time.time()
for n in tqdm(range(len(enhanced_wav_list))):
    addr_clean = os.path.join(DB_dir, os.sep.join(enhanced_wav_list[n].split(os.sep)[-1].split('_')[:3]))
    _, clean = wav.read(addr_clean+'.wav')
    # clean = clean[225:]

    fs, enhanced = wav.read(enhanced_wav_list[n])
    
    clean = clean/32768
    enhanced = enhanced/32768

    ntype_idx = enhanced_wav_list[n].split(os.sep)[-3]
    m = ntype_lib.index(ntype_idx)
    snrtype_idx = enhanced_wav_list[n].split(os.sep)[-2]
    l = snrtype_lib.index(snrtype_idx)
    vsdr, _, _, _, vstoi = ssplib.objective_measurements(clean, enhanced, fs)
    # print(enhanced_wav_list[n][50:], "  vsdr impr = ", vsdr - np.float(snrtype_idx.split('dB')[0]))
    score_sdr[m][l].append(vsdr - np.float(snrtype_idx.split('dB')[0]))
#     print("score sdr = ", score_sdr)
    score_stoi[m][l].append(vstoi)

# score_sdr = np.array(score_sdr)
print("score_sdr", score_sdr)
mean_sdr = np.mean(score_sdr, 2)
mean_stoi = np.mean(score_stoi, 2)
end_time = time.time()
print('time: {}'.format(end_time - start_time))

logger.info('SDR')
logger.info("\n".join(" ".join(map(str, line)) for line in mean_sdr))

logger.info('STOI')
logger.info("\n".join(" ".join(map(str, line)) for line in mean_stoi))
